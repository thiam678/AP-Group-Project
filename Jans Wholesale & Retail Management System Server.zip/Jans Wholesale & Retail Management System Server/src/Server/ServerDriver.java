package Server;

public class ServerDriver {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

		new Server();
	}

}
