package domain;

/*The accounting personnel need to print reports on various aspects of the system. 
 * They should be able to pull the data on a particular product between a particular period. 
 * This should aid them in analyzing the customer demand for the product to
 *  determine if it should be restocked, or the rate at which that product should be restocked.
 * 
 * */
public class SalesReport 
{
	
	
}
