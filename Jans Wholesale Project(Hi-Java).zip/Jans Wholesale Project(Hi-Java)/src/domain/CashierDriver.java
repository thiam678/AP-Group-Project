package domain;

import java.util.ArrayList;
import java.util.List;

import controller.StaffController;

public class CashierDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StaffController cashier = new StaffController();
		Employee employee = new Employee("1001", "John Public", "publicj@anemail.com", "8765556666");
		Employee employee1 = new Employee("1002", "Devon House", "devonhousej@anemail.com", "8765556666");
		Employee employee2 = new Employee("1003", "Den Hill", "denhill@anemail.com", "8765556666");
		/*cashier.sendAction("Create Employee");
		System.out.println("Message sent to server");
		
		cashier.sendEmployee(employee2);
		System.out.println("Record sent to server");
		
		cashier.recieveResponse();
		System.out.println("Response received");*/
		
		/*cashier.sendAction("Update Employee Email");
		cashier.sendEmployeeId("1003");
		cashier.sendEmployeeEmail("dud@gaming.com");
		System.out.println("Message sent to server");
		
		cashier.recieveResponse();
		System.out.println("Response received");*/
		
		/*cashier.sendAction("Update Employee Telephone");
		cashier.sendEmployeeId("1003");
		cashier.sendEmployeeEmail("8762874869");
		System.out.println("Message sent to server");
		cashier.recieveResponse();
		System.out.println("Response received");*/
		
		/*cashier.sendAction("View All Employee Records");
		List<Employee> employeeList = new ArrayList<Employee>();
		//studentList.addAll(studentList);
		employeeList = cashier.recieveResponse();
		for (Employee employee3 : employeeList) 
		{
			System.out.println(employee3);
			
		}
		System.out.println("Response received");*/
		
		
		cashier.sendAction("Find Employee Record");
		cashier.sendEmployeeId("1004");
		System.out.println("Message sent to server");
		
		cashier.recieveResponse();
		System.out.println("Response received");
	
		
		/*
		cashier.sendAction("Delete Employee Record");
		cashier.sendEmployeeId("1002");
		System.out.println("Message sent to server");
		
		cashier.recieveResponse();
		System.out.println("Response received");*/
		
	}

}
